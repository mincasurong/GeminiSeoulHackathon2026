import networkx as nx
import os
import json
import google.generativeai as genai
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List

# Load environment variables
load_dotenv()

app = FastAPI(title="Spatial AI SaaS Backend")

# Configure Gemini
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    print("WARNING: GOOGLE_API_KEY not found in environment.")
else:
    genai.configure(api_key=api_key)

# Allow CORS for Next.js
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory session graph
session_graph = nx.DiGraph()

class QueryPayload(BaseModel):
    user_query: str
    current_node: str

@app.post("/api/upload-node")
async def upload_node(
    node_name: str = Form(...),
    images: List[UploadFile] = File(...)
):
    # For hackathon demo, we allow 0-8 images but backend still expects 8 in reality
    # session_graph handles the topology
    session_graph.add_node(node_name, state="captured")
    
    nodes = list(session_graph.nodes())
    if len(nodes) > 1:
        # Simple linear link for demo, real system would use visual similarity
        session_graph.add_edge(nodes[-2], node_name)

    return {
        "status": "success",
        "node_name": node_name,
        "total_nodes": len(session_graph.nodes()),
        "edges": list(session_graph.edges()),
        "message": f"Successfully processed images for node {node_name}."
    }

@app.post("/api/query-planner")
async def query_planner(payload: QueryPayload):
    current_node = payload.current_node
    
    if current_node not in session_graph.nodes() and len(session_graph.nodes()) > 0:
        # Fallback to first node if current not found for demo
        current_node = list(session_graph.nodes())[0]

    # Construct the spatial context for Gemini
    nodes_list = list(session_graph.nodes())
    edges_list = list(session_graph.edges())
    
    prompt = f"""
    You are the 'NanoBanana' Spatial Intelligence Brain. 
    A robot is navigating a topological graph of a home.
    
    Current Map Topology:
    Nodes: {nodes_list}
    Edges (paths between nodes): {edges_list}
    
    Robot is currently at: {current_node}
    User Command: "{payload.user_query}"
    
    Task: Plan a path through the graph to fulfill the user's intent. 
    If the target isn't explicitly a node, infer which node is most likely (e.g. 'microwave' is likely in 'kitchen').
    
    Return your response in STRICT JSON format:
    {{
      "status": "success",
      "plan": ["node_1", "node_2", "target_node"],
      "message": "A short natural language explanation of the path."
    }}
    """

    try:
        model = genai.GenerativeModel('gemini-2.0-flash')
        response = model.generate_content(prompt)
        
        # Extract JSON from the response text (handling potential markdown blocks)
        text = response.text
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
            
        data = json.loads(text)
        return data
        
    except Exception as e:
        print(f"Gemini Error: {e}")
        # Fallback to dummy if Gemini fails
        return {
            "status": "success",
            "plan": [current_node, "error_fallback"],
            "message": f"Gemini could not process: {str(e)}"
        }

@app.get("/api/graph")
async def get_graph():
    nodes = [{"id": str(n), "data": {"label": str(n)}} for n in session_graph.nodes()]
    edges = [{"id": f"e-{u}-{v}", "source": str(u), "target": str(v)} for u, v in session_graph.edges()]
    return {"nodes": nodes, "edges": edges}
