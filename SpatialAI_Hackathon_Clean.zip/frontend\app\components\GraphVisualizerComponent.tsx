"use client";

import { useEffect, useState, useCallback } from "react";
import ReactFlow, {
    Background,
    Controls,
    MiniMap,
    Node,
    Edge,
    applyNodeChanges,
    applyEdgeChanges,
    NodeChange,
    EdgeChange,
} from "reactflow";
import "reactflow/dist/style.css";

export default function GraphVisualizerComponent() {
    const [nodes, setNodes] = useState<Node[]>([]);
    const [edges, setEdges] = useState<Edge[]>([]);

    const fetchGraph = async () => {
        try {
            const res = await fetch("http://localhost:8000/api/graph");
            const data = await res.json();

            // Map API nodes to ReactFlow nodes
            const formattedNodes = data.nodes.map((n: any, i: number) => ({
                id: n.id,
                // Layout randomly or use a layout engine like Dagre in a real app
                position: { x: (i % 5) * 150 + 50, y: Math.floor(i / 5) * 100 + 50 },
                data: { label: n.id },
                style: {
                    background: '#1e293b',
                    color: '#f8fafc',
                    border: '1px solid #475569',
                    borderRadius: '8px',
                    padding: '10px 15px',
                    minWidth: '120px',
                    textAlign: 'center' as const,
                }
            }));

            const formattedEdges = data.edges.map((e: any) => ({
                id: e.id,
                source: e.source,
                target: e.target,
                animated: true,
                style: { stroke: '#818cf8', strokeWidth: 2 }
            }));

            setNodes(formattedNodes);
            setEdges(formattedEdges);
        } catch (err) {
            console.error("Error fetching graph data:", err);
        }
    };

    useEffect(() => {
        // Initial fetch
        fetchGraph();
        // Poll every 5 seconds for updates
        const interval = setInterval(fetchGraph, 5000);
        return () => clearInterval(interval);
    }, []);

    const onNodesChange = useCallback(
        (changes: NodeChange[]) => setNodes((nds) => applyNodeChanges(changes, nds)),
        []
    );

    const onEdgesChange = useCallback(
        (changes: EdgeChange[]) => setEdges((eds) => applyEdgeChanges(changes, eds)),
        []
    );

    return (
        <div className="w-full h-full relative" style={{ minHeight: '400px' }}>
            <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                fitView
            >
                <Background gap={16} size={1} color="#334155" />
                <Controls showInteractive={false} className="bg-gray-800 border-none fill-white" />
                <MiniMap
                    nodeColor="#475569"
                    maskColor="rgba(15, 23, 42, 0.7)"
                    style={{ backgroundColor: '#1e293b' }}
                />
            </ReactFlow>
        </div>
    );
}
