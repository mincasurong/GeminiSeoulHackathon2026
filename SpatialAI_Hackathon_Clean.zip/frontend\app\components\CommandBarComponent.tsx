"use client";

import { useState } from "react";
import { Terminal, Send, ArrowRight } from "lucide-react";

export default function CommandBarComponent() {
    const [query, setQuery] = useState("");
    const [currentNode, setCurrentNode] = useState("hallway_1");
    const [loading, setLoading] = useState(false);
    const [plan, setPlan] = useState<string[]>([]);
    const [error, setError] = useState("");

    const submitQuery = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!query) return;

        setLoading(true);
        setError("");
        setPlan([]);

        try {
            const res = await fetch("http://localhost:8000/api/query-planner", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    user_query: query,
                    current_node: currentNode,
                }),
            });

            const data = await res.json();
            if (res.ok && data.status === "success") {
                setPlan(data.plan);
            } else {
                setError(data.message || "Failed to generate plan.");
            }
        } catch (err) {
            console.error(err);
            setError("Network error connecting to AI Planner API.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-gray-950 p-6">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider flex items-center">
                    <Terminal className="w-4 h-4 mr-2" />
                    Spatial Intelligence Console
                </h3>

                <div className="flex items-center space-x-2 text-xs">
                    <span className="text-gray-500">Robot Actor State:</span>
                    <input
                        className="bg-gray-900 border border-gray-800 rounded px-2 py-1 text-gray-300 w-32 focus:outline-none"
                        value={currentNode}
                        onChange={(e) => setCurrentNode(e.target.value)}
                        placeholder="Starting node"
                    />
                </div>
            </div>

            {/* Query Bar */}
            <form onSubmit={submitQuery} className="flex space-x-3 mb-6">
                <div className="flex-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-indigo-500 font-mono animate-pulse">{">"}</span>
                    </div>
                    <input
                        type="text"
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg pl-8 pr-4 py-3 text-gray-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-sm placeholder-gray-600 shadow-inner"
                        placeholder="e.g. Find the microwave..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                </div>
                <button
                    type="submit"
                    disabled={loading || !query}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-6 flex items-center justify-center transition-colors disabled:opacity-50"
                >
                    {loading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                        <Send className="w-4 h-4" />
                    )}
                </button>
            </form>

            {/* Execution Plan Output */}
            <div className="flex-1 overflow-y-auto bg-gray-900/50 rounded-lg p-4 font-mono text-sm border border-gray-800">
                {error ? (
                    <div className="text-red-400">Error: {error}</div>
                ) : plan.length > 0 ? (
                    <div>
                        <div className="text-green-400 mb-3">✓ Trajectory synthesized successfully.</div>
                        <div className="flex flex-wrap items-center text-gray-300 pt-2 gap-y-2">
                            {plan.map((step, idx) => (
                                <div key={idx} className="flex items-center">
                                    <div className="px-3 py-1 bg-gray-800 border border-gray-700 rounded-md text-gray-200">
                                        {step}
                                    </div>
                                    {idx < plan.length - 1 && (
                                        <ArrowRight className="w-4 h-4 mx-2 text-gray-500" />
                                    )}
                                </div>
                            ))}
                        </div>

                        <button className="mt-6 px-4 py-2 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 rounded-md hover:bg-emerald-600/30 transition-colors text-xs font-sans">
                            EXECUTE PLAN
                        </button>
                    </div>
                ) : (
                    <div className="text-gray-600 h-full flex items-center justify-center">
                        Awaiting instruction input...
                    </div>
                )}
            </div>
        </div>
    );
}
