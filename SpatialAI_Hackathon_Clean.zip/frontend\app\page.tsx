import NodeCaptureComponent from "./components/NodeCaptureComponent";
import GraphVisualizerComponent from "./components/GraphVisualizerComponent";
import CommandBarComponent from "./components/CommandBarComponent";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 flex flex-col font-sans">
      {/* Header */}
      <header className="bg-gray-900 border-b border-gray-800 p-4 shrink-0 shadow-sm z-10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center font-bold text-white shadow-lg">
              S
            </div>
            <h1 className="text-xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-gray-100 to-gray-400">
              SpatialAI Planner
            </h1>
          </div>
          <div className="flex space-x-3">
            <button className="px-3 py-1.5 text-sm rounded bg-gray-800 hover:bg-gray-700 transition-colors border border-gray-700">Settings</button>
            <button className="px-3 py-1.5 text-sm rounded bg-indigo-600 hover:bg-indigo-500 transition-colors shadow-md text-white font-medium">Connect Robot</button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Panel: Node Capture */}
        <div className="w-1/3 min-w-[350px] border-r border-gray-800 bg-gray-900/50 flex flex-col overflow-y-auto">
          <div className="p-6 flex-1">
            <h2 className="text-lg font-medium mb-4 flex items-center text-gray-200">
              <span className="w-2 h-2 rounded-full bg-blue-500 mr-2 animate-pulse"></span>
              Environment Capture
            </h2>
            <p className="text-sm text-gray-400 mb-6">
              Upload 8 directional images to synthesize a new topological node in the spatial graph.
            </p>
            <NodeCaptureComponent />
          </div>
        </div>

        {/* Right Panel: Graph & Command */}
        <div className="flex-1 flex flex-col bg-gray-950">
          <div className="flex-1 relative">
            <GraphVisualizerComponent />
            
            {/* Absolute Overlay for Dashboard Badges if needed */}
            <div className="absolute top-4 left-4 flex gap-2 z-10">
               <div className="bg-gray-900/80 backdrop-blur border border-gray-800 px-3 py-1.5 rounded-md text-xs font-medium text-gray-300 shadow-sm flex items-center">
                 Status: <span className="text-emerald-400 ml-1">Live</span>
               </div>
            </div>
          </div>
          
          <div className="h-1/3 min-h-[250px] border-t border-gray-800 bg-gray-900 shadow-inner flex flex-col">
            <CommandBarComponent />
          </div>
        </div>
      </main>
    </div>
  );
}
